# TATKAL X - Native Android Application

**TATKAL X** is a high-precision, battery-efficient railway Tatkal booking assistant built with **Native Android**, **Kotlin**, **Jetpack Compose**, and **Material 3**.

- **Package Name**: `com.tatkalx.app`
- **Minimum SDK**: 26 (Android 8.0 Oreo)
- **Target SDK**: 35 (Android 15)
- **UI Toolkit**: Jetpack Compose with Material 3 Dark Railway Theme
- **Local Persistence**: Room SQLite Database + AndroidX DataStore Preferences

---

## Key Features

1. **AC Tatkal Countdown (10:00:00 AM IST)**
   - Millisecond-accurate digital clock synced with Indian Standard Time (Asia/Kolkata).
   - Real-time warnings at T-15m, T-5m, T-1m, and imminent 10-second buzzer.

2. **Sleeper Tatkal Countdown (11:00:00 AM IST)**
   - Dedicated timer for Non-AC Sleeper (SL) and 2S classes.

3. **Network Connectivity & Latency Monitoring**
   - Active transport detection (Wi-Fi, 5G, LTE).
   - Instant socket ping and jitter telemetry to verify route stability before the booking rush.

4. **Battery & Internet Readiness Diagnostics**
   - Live battery level and AC charging status.
   - Power Saver Mode detector warning against background thread throttling.

5. **Official IRCTC Rail Connect App Shortcut**
   - Direct Intent launcher for the official app (`cris.org.in.prs.ima`).
   - Seamless fallback to Google Play Store and official IRCTC web portal (`irctc.co.in`).

6. **Journey Preparation Checklist**
   - Pre-booking protocol (Master passenger list pre-filled, UPI standby, login session active).
   - Stored in local DataStore.

7. **Booking Status & PNR Record Management**
   - Offline 10-digit PNR tracker using Room database.
   - Quick one-tap redirection to Indian Railways official PNR verification portal.

8. **Dark Premium Interface with Professional Railway Theme**
   - Deep charcoal background (`#0B0F17`), signal green, rail amber, and high-contrast tabular typography.

---

## Security & Compliance Architecture

- **Zero Credential Storage**: TATKAL X never asks for, records, or stores IRCTC passwords, PINs, OTPs, or payment credentials.
- **No CAPTCHA / Rate-Limit Bypass**: Does not use unauthorized scraping, booking bots, or unofficial reverse-engineered APIs.
- **Battery & CPU Efficiency**: Timer coroutines run only while visible; network socket probes are triggered on-demand or with low duty cycle.

---

## Opening in Android Studio

1. Open **Android Studio** (2024.1+ recommended).
2. Select **Open** and choose the `android` folder.
3. Allow Gradle to sync.
4. Select an emulator or physical Android device running Android 8.0+ (API 26+).
5. Click **Run** (`Shift + F10`).
