package com.tatkalx.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pnr_records")
data class PnrRecord(
    @PrimaryKey
    val pnrNumber: String,
    val trainNumber: String,
    val trainName: String,
    val journeyDate: String,
    val fromStation: String,
    val toStation: String,
    val travelClass: String,
    val bookingStatus: String, // e.g. "CNF", "WL 12", "RAC 4"
    val currentStatus: String,
    val coachBerth: String, // e.g. "B4 - 32 (LB)" or "WL"
    val timestampAdded: Long = System.currentTimeMillis(),
    val notes: String = ""
)
