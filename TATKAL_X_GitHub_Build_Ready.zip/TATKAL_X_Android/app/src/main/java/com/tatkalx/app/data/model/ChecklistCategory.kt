package com.tatkalx.app.data.model

/**
 * Categories for Tatkal booking preparation tasks
 */
enum class ChecklistCategory {
    PRE_BOOKING,
    PAYMENT_SETUP,
    IRCTC_APP,
    POST_BOOKING
}
