package com.tatkalx.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "tatkalx_prefs")

class PreferencesManager(private val context: Context) {

    companion object {
        val KEY_COUNTDOWN_ALERT_SOUND = booleanPreferencesKey("pref_countdown_sound")
        val KEY_COUNTDOWN_VIBRATION = booleanPreferencesKey("pref_countdown_vibrate")
        val KEY_DEFAULT_SLOT = stringPreferencesKey("pref_default_slot") // "AC" or "SLEEPER"
        val KEY_LEAD_WARNING_MINUTES = intPreferencesKey("pref_lead_warning_minutes")
        val KEY_COMPLETED_CHECKLIST = stringSetPreferencesKey("pref_completed_checklist")
    }

    val soundEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_COUNTDOWN_ALERT_SOUND] ?: true
    }

    val vibrationEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_COUNTDOWN_VIBRATION] ?: true
    }

    val defaultSlot: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DEFAULT_SLOT] ?: "AC"
    }

    val leadWarningMinutes: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_LEAD_WARNING_MINUTES] ?: 5
    }

    val completedChecklistIds: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[KEY_COMPLETED_CHECKLIST] ?: emptySet()
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_COUNTDOWN_ALERT_SOUND] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_COUNTDOWN_VIBRATION] = enabled }
    }

    suspend fun setDefaultSlot(slot: String) {
        context.dataStore.edit { prefs -> prefs[KEY_DEFAULT_SLOT] = slot }
    }

    suspend fun toggleChecklistItem(id: String, completed: Boolean) {
        context.dataStore.edit { prefs ->
            val current = (prefs[KEY_COMPLETED_CHECKLIST] ?: emptySet()).toMutableSet()
            if (completed) {
                current.add(id)
            } else {
                current.remove(id)
            }
            prefs[KEY_COMPLETED_CHECKLIST] = current
        }
    }
}
