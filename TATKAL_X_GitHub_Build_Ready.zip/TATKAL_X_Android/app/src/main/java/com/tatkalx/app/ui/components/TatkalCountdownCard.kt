package com.tatkalx.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatkalx.app.data.model.TatkalSlot
import com.tatkalx.app.ui.theme.*
import com.tatkalx.app.util.TatkalCountdownState

@Composable
fun TatkalCountdownCard(
    slot: TatkalSlot,
    countdownState: TatkalCountdownState,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        countdownState.isTargetImminent -> SignalRed
        isSelected -> RailAmber
        else -> RailBorder
    }

    val glowBrush = if (countdownState.isTargetImminent) {
        Brush.verticalGradient(listOf(Color(0x33EF4444), RailSurface))
    } else {
        Brush.verticalGradient(listOf(RailSurfaceVariant, RailSurface))
    }

    Card(
        onClick = onSelect,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = RailSurface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier
                .background(glowBrush)
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = slot.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = slot.classesCovered,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                // Window time marker
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) RailAmber else RailSurfaceElevated)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${slot.targetHour}:00 AM IST",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) RailBlack else TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Atomic Digital Clock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom
            ) {
                TimeUnitBlock(value = countdownState.hours, label = "HRS")
                TimeSeparator()
                TimeUnitBlock(value = countdownState.minutes, label = "MIN")
                TimeSeparator()
                TimeUnitBlock(value = countdownState.seconds, label = "SEC", highlight = countdownState.isTargetImminent)
                TimeSeparator()
                TimeUnitBlock(value = countdownState.centiseconds, label = "MS", isMini = true)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Status message
            AnimatedVisibility(
                visible = countdownState.isTargetImminent,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x33EF4444))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "WINDOW OPENING IMMINENT! Switch to IRCTC App Now",
                        color = SignalRed,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun TimeUnitBlock(
    value: Long,
    label: String,
    highlight: Boolean = false,
    isMini: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (highlight) Color(0x22EF4444) else RailBlack)
                .border(
                    1.dp,
                    if (highlight) SignalRed else RailBorder,
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = if (isMini) 8.dp else 12.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format("%02d", value),
                fontFamily = FontFamily.Monospace,
                fontSize = if (isMini) 22.sp else 30.sp,
                fontWeight = FontWeight.Bold,
                color = if (highlight) SignalRed else TextPrimary
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextTertiary,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun TimeSeparator() {
    Text(
        text = ":",
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        color = RailAmber,
        modifier = Modifier.padding(bottom = 22.dp)
    )
}
