package com.tatkalx.app

import android.app.Application
import com.tatkalx.app.data.database.TatkalDatabase
import com.tatkalx.app.data.local.PreferencesManager

/**
 * TATKAL X Application class.
 * Initializes local storage (Room database & DataStore preferences)
 * without any external telemetries or unsafe credentials.
 */
class TatkalXApplication : Application() {

    lateinit var database: TatkalDatabase
        private set

    lateinit var preferencesManager: PreferencesManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = TatkalDatabase.getDatabase(this)
        preferencesManager = PreferencesManager(this)
    }

    companion object {
        lateinit var instance: TatkalXApplication
            private set
    }
}
