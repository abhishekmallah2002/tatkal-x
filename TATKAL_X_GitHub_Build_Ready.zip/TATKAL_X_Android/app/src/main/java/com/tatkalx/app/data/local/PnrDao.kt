package com.tatkalx.app.data.local

import com.tatkalx.app.data.database.PnrDao as DatabasePnrDao

/**
 * Backward compatibility alias for PnrDao
 */
typealias PnrDao = DatabasePnrDao
