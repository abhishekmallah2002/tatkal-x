package com.tatkalx.app.data.model

/**
 * Model representing an actionable preparation item before booking
 */
data class ChecklistItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val isCompleted: Boolean = false,
    val category: ChecklistCategory = ChecklistCategory.PRE_BOOKING,
    val priority: Int = 1
)
