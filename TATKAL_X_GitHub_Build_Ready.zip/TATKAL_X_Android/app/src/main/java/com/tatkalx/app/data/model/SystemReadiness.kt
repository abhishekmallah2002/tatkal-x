package com.tatkalx.app.data.model

/**
 * Model representing live system, battery and network readiness
 * calculated dynamically from actual device sensor readings and TCP latency measurements.
 */
data class SystemReadiness(
    val batteryPct: Int = 100,
    val isCharging: Boolean = false,
    val isPowerSaveMode: Boolean = false,
    val networkType: String = "Checking...",
    val latencyMs: Long = -1L,
    val jitterMs: Long = 0L,
    val isMeasured: Boolean = false
) {
    /**
     * Dynamic readiness calculation based strictly on real measurement values
     */
    val readinessScore: Int
        get() {
            if (!isMeasured || latencyMs <= 0) return 0
            var score = 100

            // Latency deductions based on measured TCP round trip
            when {
                latencyMs > 250 -> score -= 40
                latencyMs > 150 -> score -= 25
                latencyMs > 80 -> score -= 10
            }

            // Jitter deductions based on measured sample variance
            when {
                jitterMs > 30 -> score -= 15
                jitterMs > 15 -> score -= 8
            }

            // Battery deductions based on Android BatteryManager state
            if (batteryPct < 20 && !isCharging) {
                score -= 25
            } else if (batteryPct < 40 && !isCharging) {
                score -= 10
            }

            // Power save mode deduction
            if (isPowerSaveMode) {
                score -= 15
            }

            return score.coerceIn(0, 100)
        }

    val readinessVerdict: String
        get() = when {
            !isMeasured || latencyMs <= 0 -> "PENDING PROBE"
            readinessScore >= 85 -> "EXCELLENT READINESS"
            readinessScore >= 70 -> "ACCEPTABLE READINESS"
            else -> "OPTIMIZATION RECOMMENDED"
        }
}
