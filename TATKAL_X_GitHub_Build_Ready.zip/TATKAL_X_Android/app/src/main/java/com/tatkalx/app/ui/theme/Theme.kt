package com.tatkalx.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = RailAmber,
    onPrimary = RailBlack,
    primaryContainer = RailSurfaceVariant,
    onPrimaryContainer = RailAmber,
    secondary = TrackBlue,
    onSecondary = TextPrimary,
    tertiary = SignalGreen,
    background = RailBlack,
    surface = RailSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = RailSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = RailBorder
)

@Composable
fun TatkalXTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = RailBlack.toArgb()
            window.navigationBarColor = RailBlack.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = TatkalTypography,
        content = content
    )
}
