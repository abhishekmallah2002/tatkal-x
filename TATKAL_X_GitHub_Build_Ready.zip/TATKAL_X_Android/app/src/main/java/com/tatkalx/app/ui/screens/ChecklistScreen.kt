package com.tatkalx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatkalx.app.data.model.ChecklistItem
import com.tatkalx.app.ui.theme.*

@Composable
fun ChecklistScreen(
    items: List<ChecklistItem>,
    onToggleItem: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val completedCount = items.count { it.isCompleted }
    val progressPct = if (items.isNotEmpty()) (completedCount * 100 / items.size) else 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RailBlack)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Tatkal Readiness Checklist",
                    style = MaterialTheme.typography.displayMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Ensure 100% completion before 09:50 AM to avoid booking delays.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        // Progress Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = RailSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RailBorder, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Preparation Progress",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$completedCount of ${items.size} Completed ($progressPct%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (progressPct == 100) SignalGreen else RailAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { completedCount.toFloat() / items.size.coerceAtLeast(1) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (progressPct == 100) SignalGreen else RailAmber,
                        trackColor = RailBlack
                    )
                }
            }
        }

        // Checklist Items
        items(items, key = { it.id }) { item ->
            ChecklistRow(
                item = item,
                onToggle = { onToggleItem(item.id, !item.isCompleted) }
            )
        }
    }
}

@Composable
private fun ChecklistRow(
    item: ChecklistItem,
    onToggle: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = RailSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (item.isCompleted) SignalGreenMuted else RailBorderSubtle,
                RoundedCornerShape(14.dp)
            )
            .clickable { onToggle() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox indicator
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (item.isCompleted) SignalGreen else RailBlack)
                    .border(
                        1.5.dp,
                        if (item.isCompleted) SignalGreen else RailBorder,
                        RoundedCornerShape(6.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (item.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = RailBlack,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (item.isCompleted) TextSecondary else TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextTertiary,
                    fontSize = 12.sp
                )
            }
        }
    }
}
