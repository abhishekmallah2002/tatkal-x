package com.tatkalx.app.data.local

import com.tatkalx.app.data.database.TatkalDatabase

/**
 * Backward compatibility alias for TatkalDatabase
 */
typealias AppDatabase = TatkalDatabase
