# Proguard rules for TATKAL X
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
