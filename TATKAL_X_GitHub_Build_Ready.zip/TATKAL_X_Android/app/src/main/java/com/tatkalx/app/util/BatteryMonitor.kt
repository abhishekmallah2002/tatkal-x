package com.tatkalx.app.util

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager

class BatteryMonitor(private val context: Context) {

    fun getBatteryStatus(): BatterySnapshot {
        val batteryIntent: Intent? = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

        val batteryPct = if (level >= 0 && scale > 0) {
            (level * 100 / scale.toFloat()).toInt()
        } else {
            100
        }

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSaveMode = powerManager?.isPowerSaveMode ?: false

        return BatterySnapshot(
            levelPercentage = batteryPct,
            isCharging = isCharging,
            isPowerSaveMode = isPowerSaveMode
        )
    }
}

data class BatterySnapshot(
    val levelPercentage: Int,
    val isCharging: Boolean,
    val isPowerSaveMode: Boolean
) {
    val isSafeForBooking: Boolean
        get() = (levelPercentage >= 20 || isCharging) && !isPowerSaveMode

    val recommendation: String
        get() = when {
            isPowerSaveMode -> "Disable Battery Saver before 9:58 AM to prevent background throttling."
            levelPercentage < 20 && !isCharging -> "Connect charger immediately! Device may enter throttling or shutdown."
            isCharging -> "Plugged in. Optimal clock frequency available."
            else -> "Battery level sufficient for Tatkal window."
        }
}
