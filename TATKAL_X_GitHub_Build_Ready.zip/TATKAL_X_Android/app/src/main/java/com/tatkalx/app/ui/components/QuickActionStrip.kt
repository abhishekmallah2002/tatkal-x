package com.tatkalx.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tatkalx.app.ui.theme.*

@Composable
fun QuickActionStrip(
    onLaunchIrctc: () -> Unit,
    onOpenWebPortal: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Primary Action: Open Official IRCTC Rail Connect App
        Button(
            onClick = onLaunchIrctc,
            colors = ButtonDefaults.buttonColors(
                containerColor = RailAmber,
                contentColor = RailBlack
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(1.3f)
                .height(52.dp)
        ) {
            Text(
                text = "Launch IRCTC App",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }

        // Secondary Action: IRCTC Web
        OutlinedButton(
            onClick = onOpenWebPortal,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .weight(0.9f)
                .height(52.dp)
        ) {
            Text(
                text = "IRCTC Web",
                fontWeight = FontWeight.Medium,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
