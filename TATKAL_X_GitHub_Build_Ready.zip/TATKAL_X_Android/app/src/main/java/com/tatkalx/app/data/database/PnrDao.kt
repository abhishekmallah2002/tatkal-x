package com.tatkalx.app.data.database

import androidx.room.*
import com.tatkalx.app.data.model.PnrRecord
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for PNR record operations in Room database
 */
@Dao
interface PnrDao {
    @Query("SELECT * FROM pnr_records ORDER BY timestampAdded DESC")
    fun getAllPnrs(): Flow<List<PnrRecord>>

    @Query("SELECT * FROM pnr_records WHERE pnrNumber = :pnrNumber LIMIT 1")
    suspend fun getPnr(pnrNumber: String): PnrRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPnr(record: PnrRecord)

    @Delete
    suspend fun deletePnr(record: PnrRecord)

    @Query("DELETE FROM pnr_records WHERE pnrNumber = :pnrNumber")
    suspend fun deleteByPnrNumber(pnrNumber: String)
}
