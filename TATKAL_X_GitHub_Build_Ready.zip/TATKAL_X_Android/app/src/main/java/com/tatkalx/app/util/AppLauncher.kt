package com.tatkalx.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object AppLauncher {

    const val IRCTC_PACKAGE_NAME = "cris.org.in.prs.ima"
    const val IRCTC_WEB_PORTAL = "https://www.irctc.co.in/nget/"
    const val PLAY_STORE_URL = "market://details?id=$IRCTC_PACKAGE_NAME"
    const val PLAY_STORE_WEB_URL = "https://play.google.com/store/apps/details?id=$IRCTC_PACKAGE_NAME"

    /**
     * Checks if official IRCTC Rail Connect app is installed on this device
     */
    fun isIrctcAppInstalled(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            pm.getPackageInfo(IRCTC_PACKAGE_NAME, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Launches the official IRCTC Rail Connect app if installed,
     * otherwise opens its official Google Play Store page or the IRCTC portal.
     */
    fun launchOfficialIrctc(context: Context) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(IRCTC_PACKAGE_NAME)

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            // Open Play Store or fallback browser
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_STORE_URL)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
            } catch (_: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_STORE_WEB_URL)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
        }
    }

    /**
     * Opens official IRCTC Web Portal directly in default browser
     */
    fun openIrctcWebPortal(context: Context) {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(IRCTC_WEB_PORTAL)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(browserIntent)
    }

    /**
     * Opens official IRCTC PNR Status check page
     */
    fun openPnrEnquiry(context: Context, pnr: String = "") {
        val url = if (pnr.isNotBlank()) {
            "https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en"
        } else {
            "https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
