package com.tatkalx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatkalx.app.data.model.PnrRecord
import com.tatkalx.app.ui.theme.*
import com.tatkalx.app.util.AppLauncher

@Composable
fun PnrScreen(
    pnrList: List<PnrRecord>,
    onAddPnr: (PnrRecord) -> Unit,
    onDeletePnr: (PnrRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RailBlack)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PNR Records",
                        style = MaterialTheme.typography.displayMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Local offline storage for your booked journeys",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RailAmber,
                        contentColor = RailBlack
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add PNR")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Add PNR", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (pnrList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = RailSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No Saved PNRs Yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "After securing your Tatkal ticket on IRCTC, save your 10-digit PNR here to track status and coach allocation.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = { AppLauncher.openPnrEnquiry(context) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Official PNR Web Portal")
                        }
                    }
                }
            }
        } else {
            items(pnrList, key = { it.pnrNumber }) { record ->
                PnrCardItem(
                    record = record,
                    onCheckOfficialStatus = { AppLauncher.openPnrEnquiry(context, record.pnrNumber) },
                    onDelete = { onDeletePnr(record) }
                )
            }
        }
    }

    if (showAddDialog) {
        AddPnrDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newRecord ->
                onAddPnr(newRecord)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun PnrCardItem(
    record: PnrRecord,
    onCheckOfficialStatus: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = RailSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, RailBorder, RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PNR ${record.pnrNumber}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = RailAmber
                    )
                    Text(
                        text = "${record.trainNumber} · ${record.trainName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Status chip
                val isConfirmed = record.bookingStatus.startsWith("CNF")
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isConfirmed) SignalGreenMuted else RailAmberMuted)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = record.bookingStatus,
                        color = if (isConfirmed) SignalGreen else RailAmber,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Journey Route & Class
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${record.fromStation} → ${record.toStation}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${record.travelClass} · ${record.journeyDate}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            if (record.coachBerth.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Coach / Berth: ${record.coachBerth}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SignalGreen,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete PNR",
                        tint = TextTertiary
                    )
                }

                OutlinedButton(
                    onClick = onCheckOfficialStatus,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInBrowser,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Verify Status on IRCTC", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun AddPnrDialog(
    onDismiss: () -> Unit,
    onConfirm: (PnrRecord) -> Unit
) {
    var pnrNumber by remember { mutableStateOf("") }
    var trainNumber by remember { mutableStateOf("") }
    var trainName by remember { mutableStateOf("") }
    var journeyDate by remember { mutableStateOf("") }
    var fromStation by remember { mutableStateOf("") }
    var toStation by remember { mutableStateOf("") }
    var travelClass by remember { mutableStateOf("3A") }
    var bookingStatus by remember { mutableStateOf("CNF") }
    var coachBerth by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Record New PNR", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pnrNumber,
                    onValueChange = { if (it.length <= 10) pnrNumber = it.filter { ch -> ch.isDigit() } },
                    label = { Text("10-Digit PNR Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = trainNumber,
                        onValueChange = { trainNumber = it },
                        label = { Text("Train No.") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = trainName,
                        onValueChange = { trainName = it },
                        label = { Text("Train Name") },
                        modifier = Modifier.weight(1.5f),
                        singleLine = true
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fromStation,
                        onValueChange = { fromStation = it.uppercase() },
                        label = { Text("From Code") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = toStation,
                        onValueChange = { toStation = it.uppercase() },
                        label = { Text("To Code") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = travelClass,
                        onValueChange = { travelClass = it.uppercase() },
                        label = { Text("Class (e.g. 3A, SL)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = bookingStatus,
                        onValueChange = { bookingStatus = it.uppercase() },
                        label = { Text("Status (CNF/WL)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                OutlinedTextField(
                    value = coachBerth,
                    onValueChange = { coachBerth = it },
                    label = { Text("Coach/Berth (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pnrNumber.length == 10) {
                        onConfirm(
                            PnrRecord(
                                pnrNumber = pnrNumber,
                                trainNumber = trainNumber.ifBlank { "12951" },
                                trainName = trainName.ifBlank { "Rajdhani Express" },
                                journeyDate = journeyDate.ifBlank { "Tomorrow" },
                                fromStation = fromStation.ifBlank { "NDLS" },
                                toStation = toStation.ifBlank { "MMCT" },
                                travelClass = travelClass.ifBlank { "3A" },
                                bookingStatus = bookingStatus.ifBlank { "CNF" },
                                currentStatus = bookingStatus.ifBlank { "CNF" },
                                coachBerth = coachBerth
                            )
                        )
                    }
                },
                enabled = pnrNumber.length == 10,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RailAmber,
                    contentColor = RailBlack
                )
            ) {
                Text("Save Locally")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = RailSurfaceVariant
    )
}
