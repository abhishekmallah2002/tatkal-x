package com.tatkalx.app.util

import java.time.Duration
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object TimeUtils {

    val IST_ZONE_ID: ZoneId = ZoneId.of("Asia/Kolkata")
    private val TIME_FORMATTER = DateTimeFormatter.ofPattern("hh:mm:ss a")
    private val DATE_FORMATTER = DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy")

    fun getCurrentIstTime(): ZonedDateTime {
        return ZonedDateTime.now(IST_ZONE_ID)
    }

    fun getFormattedIstTime(now: ZonedDateTime = getCurrentIstTime()): String {
        return now.format(TIME_FORMATTER)
    }

    fun getFormattedIstDate(now: ZonedDateTime = getCurrentIstTime()): String {
        return now.format(DATE_FORMATTER)
    }

    /**
     * Calculates remaining duration until the next target hour (e.g. 10:00:00 or 11:00:00 IST).
     * If the current time is already past target today, it calculates for tomorrow's window.
     */
    fun calculateCountdownToHour(targetHour: Int, targetMinute: Int = 0): TatkalCountdownState {
        val now = getCurrentIstTime()
        var targetTime = now.with(LocalTime.of(targetHour, targetMinute, 0, 0))

        // If today's slot has already passed, the next slot is tomorrow
        if (now.isAfter(targetTime)) {
            targetTime = targetTime.plusDays(1)
        }

        val duration = Duration.between(now, targetTime)
        val totalMillis = duration.toMillis()
        val hours = duration.toHours()
        val minutes = duration.toMinutes() % 60
        val seconds = duration.seconds % 60
        val millisPart = (totalMillis % 1000) / 10 // 2-digit centiseconds

        val isTargetImminent = totalMillis in 1..60_000 // Last 60 seconds
        val isTargetActive = totalMillis in -120_000..0 // Within 2 minutes after opening

        return TatkalCountdownState(
            targetHour = targetHour,
            hours = hours,
            minutes = minutes,
            seconds = seconds,
            centiseconds = millisPart,
            totalRemainingMillis = totalMillis,
            isTargetImminent = isTargetImminent,
            isTargetActive = isTargetActive,
            formattedString = String.format("%02d:%02d:%02d", hours, minutes, seconds)
        )
    }
}

data class TatkalCountdownState(
    val targetHour: Int,
    val hours: Long,
    val minutes: Long,
    val seconds: Long,
    val centiseconds: Long,
    val totalRemainingMillis: Long,
    val isTargetImminent: Boolean,
    val isTargetActive: Boolean,
    val formattedString: String
)
