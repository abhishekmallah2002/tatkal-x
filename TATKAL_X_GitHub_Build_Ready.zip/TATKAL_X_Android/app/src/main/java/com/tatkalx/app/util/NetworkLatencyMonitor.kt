package com.tatkalx.app.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

class NetworkLatencyMonitor(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    /**
     * Inspects active network transport using Android ConnectivityManager
     */
    fun getNetworkTypeName(): String {
        val activeNetwork = connectivityManager.activeNetwork ?: return "Disconnected"
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return "Offline"

        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi (High Speed)"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) {
                    "Cellular 5G (Unmetered)"
                } else {
                    "Cellular (4G/LTE/5G)"
                }
            }
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet LAN"
            else -> "Active Mobile Network"
        }
    }

    /**
     * Performs real socket connection probe to measure actual round-trip latency.
     * Takes multiple consecutive samples to compute true packet jitter.
     */
    suspend fun measureRealLatency(
        host: String = "1.1.1.1",
        port: Int = 53,
        samples: Int = 3,
        timeoutMs: Int = 1500
    ): RealLatencyResult = withContext(Dispatchers.IO) {
        val latencies = mutableListOf<Long>()

        for (i in 0 until samples) {
            val startTime = System.currentTimeMillis()
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.connect(InetSocketAddress(host, port), timeoutMs)
                val rtt = System.currentTimeMillis() - startTime
                latencies.add(rtt)
                socket.close()
            } catch (e: IOException) {
                try { socket?.close() } catch (_: Exception) {}
            }
        }

        if (latencies.isEmpty()) {
            return@withContext RealLatencyResult(
                isSuccess = false,
                averageLatencyMs = -1L,
                jitterMs = 0L,
                qualityLabel = "Probe Unreachable",
                host = host,
                samplesCount = 0
            )
        }

        val avg = latencies.average().toLong()

        // Real jitter calculation: average difference between consecutive samples
        var totalJitter = 0L
        if (latencies.size > 1) {
            for (i in 1 until latencies.size) {
                totalJitter += abs(latencies[i] - latencies[i - 1])
            }
            totalJitter /= (latencies.size - 1)
        }

        val quality = when {
            avg < 40 -> "Optimal for Tatkal (<40ms)"
            avg < 80 -> "Good Performance (<80ms)"
            avg < 150 -> "Acceptable (<150ms)"
            else -> "High Latency (>150ms)"
        }

        RealLatencyResult(
            isSuccess = true,
            averageLatencyMs = avg,
            jitterMs = totalJitter,
            qualityLabel = quality,
            host = host,
            samplesCount = latencies.size
        )
    }
}

data class RealLatencyResult(
    val isSuccess: Boolean,
    val averageLatencyMs: Long,
    val jitterMs: Long,
    val qualityLabel: String,
    val host: String,
    val samplesCount: Int,
    val errorMessage: String? = null
)
