package com.tatkalx.app.data.model

enum class TatkalSlotType {
    AC,
    SLEEPER
}

data class TatkalSlot(
    val type: TatkalSlotType,
    val title: String,
    val targetHour: Int, // 10 for AC, 11 for Sleeper (24h format IST)
    val targetMinute: Int = 0,
    val description: String,
    val classesCovered: String,
    val quotaWindowDescription: String
) {
    companion object {
        val AC_SLOT = TatkalSlot(
            type = TatkalSlotType.AC,
            title = "AC Tatkal Window",
            targetHour = 10,
            targetMinute = 0,
            description = "1A, 2A, 3A, CC, EC, 3E Classes",
            classesCovered = "Executive, 1st AC, 2 Tier, 3 Tier AC",
            quotaWindowDescription = "Opens precisely at 10:00:00 AM IST one day prior to journey date from originating station."
        )

        val SLEEPER_SLOT = TatkalSlot(
            type = TatkalSlotType.SLEEPER,
            title = "Sleeper Tatkal Window",
            targetHour = 11,
            targetMinute = 0,
            description = "SL and 2S Non-AC Classes",
            classesCovered = "Sleeper Class (SL), Second Sitting (2S)",
            quotaWindowDescription = "Opens precisely at 11:00:00 AM IST one day prior to journey date from originating station."
        )
    }
}
