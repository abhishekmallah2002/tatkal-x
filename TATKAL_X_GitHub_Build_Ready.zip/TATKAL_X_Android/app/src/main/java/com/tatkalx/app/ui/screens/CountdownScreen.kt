package com.tatkalx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatkalx.app.data.model.TatkalSlot
import com.tatkalx.app.ui.components.TatkalCountdownCard
import com.tatkalx.app.ui.theme.*
import com.tatkalx.app.util.TimeUtils

@Composable
fun CountdownScreen(modifier: Modifier = Modifier) {
    var acCountdown by remember { mutableStateOf(TimeUtils.calculateCountdownToHour(10)) }
    var sleeperCountdown by remember { mutableStateOf(TimeUtils.calculateCountdownToHour(11)) }
    var istFormattedTime by remember { mutableStateOf(TimeUtils.getFormattedIstTime()) }
    var istFormattedDate by remember { mutableStateOf(TimeUtils.getFormattedIstDate()) }

    LaunchedEffect(Unit) {
        while (true) {
            acCountdown = TimeUtils.calculateCountdownToHour(10)
            sleeperCountdown = TimeUtils.calculateCountdownToHour(11)
            istFormattedTime = TimeUtils.getFormattedIstTime()
            istFormattedDate = TimeUtils.getFormattedIstDate()
            kotlinx.coroutines.delay(80L)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RailBlack)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Tatkal Clocks",
                    style = MaterialTheme.typography.displayMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$istFormattedDate · $istFormattedTime IST",
                    style = MaterialTheme.typography.bodyMedium,
                    color = RailAmber
                )
            }
        }

        // AC Tatkal 10:00 AM card
        item {
            TatkalCountdownCard(
                slot = TatkalSlot.AC_SLOT,
                countdownState = acCountdown,
                isSelected = true,
                onSelect = {}
            )
        }

        // Sleeper Tatkal 11:00 AM card
        item {
            TatkalCountdownCard(
                slot = TatkalSlot.SLEEPER_SLOT,
                countdownState = sleeperCountdown,
                isSelected = false,
                onSelect = {}
            )
        }

        // Timeline milestones guide
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = RailSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RailBorder, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Booking Protocol Timeline",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    MilestoneRow(
                        timeLabel = "09:55 AM",
                        title = "Login Session Initialization",
                        description = "Log in to IRCTC Rail Connect or web portal. Solve initial captcha and confirm master list.",
                        isActive = false
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    MilestoneRow(
                        timeLabel = "09:58 AM",
                        title = "Search & Class Warmup",
                        description = "Select Origin, Destination, Date, and Quota (Tatkal). Stay on train list page.",
                        isActive = false
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    MilestoneRow(
                        timeLabel = "09:59:58 AM",
                        title = "Atomic Refresh",
                        description = "Tap Class (3A/2A/SL) at 10:00:00 or 11:00:00 sharp. Immediately select Master Passenger List.",
                        isActive = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    MilestoneRow(
                        timeLabel = "10:00:45 AM",
                        title = "Fast Payment Checkout",
                        description = "Choose UPI QR/VPA. Complete biometric push authorization without reloading page.",
                        isActive = false
                    )
                }
            }
        }
    }
}

@Composable
private fun MilestoneRow(
    timeLabel: String,
    title: String,
    description: String,
    isActive: Boolean
) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .size(10.dp)
                .clip(CircleShape)
                .background(if (isActive) SignalGreen else RailBorder)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = timeLabel,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) SignalGreen else RailAmber
                )
                Text(
                    text = " · $title",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            }
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
