package com.tatkalx.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tatkalx.app.data.model.PnrRecord

/**
 * Room Database for offline PNR records and local journey persistence
 */
@Database(entities = [PnrRecord::class], version = 1, exportSchema = false)
abstract class TatkalDatabase : RoomDatabase() {

    abstract fun pnrDao(): PnrDao

    companion object {
        @Volatile
        private var INSTANCE: TatkalDatabase? = null

        fun getDatabase(context: Context): TatkalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TatkalDatabase::class.java,
                    "tatkalx_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
