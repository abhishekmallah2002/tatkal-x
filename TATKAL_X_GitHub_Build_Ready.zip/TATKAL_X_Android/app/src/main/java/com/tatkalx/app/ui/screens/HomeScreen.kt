package com.tatkalx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tatkalx.app.data.model.SystemReadiness
import com.tatkalx.app.data.model.TatkalSlot
import com.tatkalx.app.ui.components.QuickActionStrip
import com.tatkalx.app.ui.components.SystemReadinessCard
import com.tatkalx.app.ui.components.TatkalCountdownCard
import com.tatkalx.app.ui.theme.*
import com.tatkalx.app.util.AppLauncher
import com.tatkalx.app.util.TimeUtils

@Composable
fun HomeScreen(
    readiness: SystemReadiness,
    onRetestPing: () -> Unit,
    onNavigateToChecklist: () -> Unit,
    onNavigateToPnr: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedSlotType by remember { mutableStateOf(TatkalSlot.AC_SLOT.type) }
    
    // Live ticking countdown
    var acCountdown by remember { mutableStateOf(TimeUtils.calculateCountdownToHour(10)) }
    var sleeperCountdown by remember { mutableStateOf(TimeUtils.calculateCountdownToHour(11)) }
    var istFormattedTime by remember { mutableStateOf(TimeUtils.getFormattedIstTime()) }

    LaunchedEffect(Unit) {
        while (true) {
            acCountdown = TimeUtils.calculateCountdownToHour(10)
            sleeperCountdown = TimeUtils.calculateCountdownToHour(11)
            istFormattedTime = TimeUtils.getFormattedIstTime()
            kotlinx.coroutines.delay(100L) // smooth 10Hz updates for centiseconds
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(RailBlack)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header & IST Sync Badge
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TATKAL X",
                        style = MaterialTheme.typography.displayMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Precision Railway Booking Assistant",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                // Live IST Clock
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(RailSurfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "IST SYNCED",
                            style = MaterialTheme.typography.labelSmall,
                            color = SignalGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = istFormattedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Official IRCTC Launcher Button
        item {
            QuickActionStrip(
                onLaunchIrctc = { AppLauncher.launchOfficialIrctc(context) },
                onOpenWebPortal = { AppLauncher.openIrctcWebPortal(context) }
            )
        }

        // Tab Selector between AC (10:00 AM) and Sleeper (11:00 AM)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(RailSurface)
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { selectedSlotType = TatkalSlot.AC_SLOT.type },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSlotType == TatkalSlot.AC_SLOT.type) RailAmber else Color.Transparent,
                        contentColor = if (selectedSlotType == TatkalSlot.AC_SLOT.type) RailBlack else TextSecondary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "AC Tatkal · 10 AM",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Button(
                    onClick = { selectedSlotType = TatkalSlot.SLEEPER_SLOT.type },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSlotType == TatkalSlot.SLEEPER_SLOT.type) RailAmber else Color.Transparent,
                        contentColor = if (selectedSlotType == TatkalSlot.SLEEPER_SLOT.type) RailBlack else TextSecondary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Sleeper Tatkal · 11 AM",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Primary Countdown Card
        item {
            if (selectedSlotType == TatkalSlot.AC_SLOT.type) {
                TatkalCountdownCard(
                    slot = TatkalSlot.AC_SLOT,
                    countdownState = acCountdown,
                    isSelected = true,
                    onSelect = {}
                )
            } else {
                TatkalCountdownCard(
                    slot = TatkalSlot.SLEEPER_SLOT,
                    countdownState = sleeperCountdown,
                    isSelected = true,
                    onSelect = {}
                )
            }
        }

        // System & Network Readiness Card
        item {
            SystemReadinessCard(
                readiness = readiness,
                onTestPingClick = onRetestPing
            )
        }

        // Fair Use & Official Security Disclaimer Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = RailSurfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Fair Use Notice",
                        tint = RailAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Safe & Compliant Assistant",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "TATKAL X assists with precise timing, ping stability, and checklist preparation. It never collects IRCTC passwords, bypasses CAPTCHAs, or uses unauthorized booking scripts.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
