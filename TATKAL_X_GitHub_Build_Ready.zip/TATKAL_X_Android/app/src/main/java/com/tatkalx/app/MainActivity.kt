package com.tatkalx.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.lifecycleScope
import com.tatkalx.app.data.model.ChecklistCategory
import com.tatkalx.app.data.model.ChecklistItem
import com.tatkalx.app.data.model.PnrRecord
import com.tatkalx.app.data.model.SystemReadiness
import com.tatkalx.app.ui.screens.*
import com.tatkalx.app.ui.theme.RailAmber
import com.tatkalx.app.ui.theme.RailBlack
import com.tatkalx.app.ui.theme.RailBorder
import com.tatkalx.app.ui.theme.RailSurface
import com.tatkalx.app.ui.theme.TatkalXTheme
import com.tatkalx.app.ui.theme.TextPrimary
import com.tatkalx.app.ui.theme.TextSecondary
import com.tatkalx.app.util.BatteryMonitor
import com.tatkalx.app.util.NetworkLatencyMonitor
import kotlinx.coroutines.launch

enum class AppDestination(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Dashboard),
    COUNTDOWN("Clocks", Icons.Default.Timer),
    NETWORK("Latency", Icons.Default.Speed),
    CHECKLIST("Checklist", Icons.Default.Checklist),
    PNR("PNR", Icons.Default.ConfirmationNumber)
}

class MainActivity : ComponentActivity() {

    private lateinit var latencyMonitor: NetworkLatencyMonitor
    private lateinit var batteryMonitor: BatteryMonitor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        latencyMonitor = NetworkLatencyMonitor(this)
        batteryMonitor = BatteryMonitor(this)

        setContent {
            TatkalXTheme {
                MainContent()
            }
        }
    }

    @Composable
    private fun MainContent() {
        var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
        var readiness by remember {
            val battery = batteryMonitor.getBatteryStatus()
            mutableStateOf(
                SystemReadiness(
                    batteryPct = battery.levelPercentage,
                    isCharging = battery.isCharging,
                    isPowerSaveMode = battery.isPowerSaveMode,
                    networkType = latencyMonitor.getNetworkTypeName(),
                    latencyMs = -1L,
                    jitterMs = 0L,
                    isMeasured = false
                )
            )
        }

        fun runPingProbe() {
            lifecycleScope.launch {
                val ping = latencyMonitor.measureRealLatency("1.1.1.1", samples = 3)
                val battery = batteryMonitor.getBatteryStatus()
                readiness = readiness.copy(
                    latencyMs = if (ping.isSuccess) ping.averageLatencyMs else -1L,
                    jitterMs = ping.jitterMs,
                    batteryPct = battery.levelPercentage,
                    isCharging = battery.isCharging,
                    isPowerSaveMode = battery.isPowerSaveMode,
                    networkType = latencyMonitor.getNetworkTypeName(),
                    isMeasured = ping.isSuccess
                )
            }
        }

        // Room Database & PNR Records
        val database = (application as TatkalXApplication).database
        val pnrList by database.pnrDao().getAllPnrs().collectAsState(initial = emptyList())

        // Default Tatkal Checklist
        var checklist by remember {
            mutableStateOf(
                listOf(
                    ChecklistItem("1", "Master Passenger List Created", "Pre-fill names, age, berth preference in IRCTC profile", true, ChecklistCategory.PRE_BOOKING),
                    ChecklistItem("2", "IRCTC Login Credentials Verified", "Ensure password isn't expired & solve sample captcha", true, ChecklistCategory.PRE_BOOKING),
                    ChecklistItem("3", "UPI ID / QR Payment Ready", "Keep UPI app open on another device or finger ready for prompt", false, ChecklistCategory.PAYMENT_SETUP),
                    ChecklistItem("4", "Wi-Fi & Cellular Data Standby", "Test latency under 80ms; keep mobile data toggled on", true, ChecklistCategory.PRE_BOOKING),
                    ChecklistItem("5", "Device Battery > 50% or Charging", "Prevent thermal throttling or Android battery saver killing webview", false, ChecklistCategory.PRE_BOOKING),
                    ChecklistItem("6", "Close Background Apps & Downloads", "Free RAM and prioritize TCP buffer for IRCTC transaction", false, ChecklistCategory.IRCTC_APP)
                )
            )
        }

        // Automatic initial measurement on startup
        LaunchedEffect(Unit) {
            runPingProbe()
        }

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                NavigationBar(
                    containerColor = RailSurface,
                    tonalElevation = NavigationBarDefaults.Elevation
                ) {
                    AppDestination.values().forEach { destination ->
                        val isSelected = currentDestination == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = destination },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.title,
                                    tint = if (isSelected) RailAmber else TextSecondary
                                )
                            },
                            label = {
                                Text(
                                    text = destination.title,
                                    color = if (isSelected) RailAmber else TextSecondary
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = RailSurface
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            when (currentDestination) {
                AppDestination.HOME -> HomeScreen(
                    readiness = readiness,
                    onRetestPing = { runPingProbe() },
                    onNavigateToChecklist = { currentDestination = AppDestination.CHECKLIST },
                    onNavigateToPnr = { currentDestination = AppDestination.PNR },
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestination.COUNTDOWN -> CountdownScreen(
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestination.NETWORK -> NetworkMonitorScreen(
                    readiness = readiness,
                    onRunProbe = { runPingProbe() },
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestination.CHECKLIST -> ChecklistScreen(
                    items = checklist,
                    onToggleItem = { id, completed ->
                        checklist = checklist.map {
                            if (it.id == id) it.copy(isCompleted = completed) else it
                        }
                    },
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestination.PNR -> PnrScreen(
                    pnrList = pnrList,
                    onAddPnr = { record ->
                        lifecycleScope.launch {
                            database.pnrDao().insertPnr(record)
                        }
                    },
                    onDeletePnr = { record ->
                        lifecycleScope.launch {
                            database.pnrDao().deletePnr(record)
                        }
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
