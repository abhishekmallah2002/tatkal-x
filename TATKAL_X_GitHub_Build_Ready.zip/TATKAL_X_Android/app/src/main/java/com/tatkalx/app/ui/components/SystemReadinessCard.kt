package com.tatkalx.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatkalx.app.data.model.SystemReadiness
import com.tatkalx.app.ui.theme.*

@Composable
fun SystemReadinessCard(
    readiness: SystemReadiness,
    onTestPingClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = RailSurface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, RailBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Device & Network Readiness",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Score Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (!readiness.isMeasured) RailSurfaceElevated else if (readiness.readinessScore >= 80) SignalGreenMuted else Color(0x33EF4444))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (readiness.isMeasured) "${readiness.readinessScore}% READY" else "PROBING...",
                        color = if (!readiness.isMeasured) TextSecondary else if (readiness.readinessScore >= 80) SignalGreen else SignalRed,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3-column stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReadinessMetricBox(
                    title = "Latency",
                    value = if (readiness.isMeasured && readiness.latencyMs > 0) "${readiness.latencyMs} ms" else "Measuring...",
                    subtext = "Real TCP Ping",
                    isGood = !readiness.isMeasured || readiness.latencyMs < 100,
                    modifier = Modifier.weight(1f)
                )

                ReadinessMetricBox(
                    title = "Battery",
                    value = "${readiness.batteryPct}%",
                    subtext = if (readiness.isCharging) "Charging" else if (readiness.isPowerSaveMode) "Power Saver ON" else "Unplugged",
                    isGood = (readiness.batteryPct >= 20 || readiness.isCharging) && !readiness.isPowerSaveMode,
                    modifier = Modifier.weight(1f)
                )

                ReadinessMetricBox(
                    title = "Jitter",
                    value = if (readiness.isMeasured) "±${readiness.jitterMs} ms" else "--",
                    subtext = if (readiness.isMeasured) (if (readiness.jitterMs < 15) "Stable" else "Fluctuating") else "Measuring...",
                    isGood = !readiness.isMeasured || readiness.jitterMs < 15,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Retest latency button
            Button(
                onClick = onTestPingClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RailSurfaceVariant,
                    contentColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Run Instant Latency Probe",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun ReadinessMetricBox(
    title: String,
    value: String,
    subtext: String,
    isGood: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(RailBlack)
            .border(1.dp, if (isGood) RailBorderSubtle else Color(0x44EF4444), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = if (isGood) TextPrimary else SignalRed
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                fontSize = 10.sp
            )
        }
    }
}
