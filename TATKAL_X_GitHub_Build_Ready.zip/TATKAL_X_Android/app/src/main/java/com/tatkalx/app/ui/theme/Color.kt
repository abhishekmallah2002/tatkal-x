package com.tatkalx.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Railway Dark Palette
val RailBlack = Color(0xFF0B0F17)
val RailSurface = Color(0xFF141B26)
val RailSurfaceVariant = Color(0xFF1E2738)
val RailSurfaceElevated = Color(0xFF263248)

// Accent and Signals
val RailAmber = Color(0xFFF59E0B)
val RailAmberVariant = Color(0xFFD97706)
val RailAmberMuted = Color(0x33F59E0B)

val SignalGreen = Color(0xFF10B981)
val SignalGreenVariant = Color(0xFF059669)
val SignalGreenMuted = Color(0x2210B981)

val SignalRed = Color(0xFFEF4444)
val SignalRedMuted = Color(0x22EF4444)

val TrackBlue = Color(0xFF3B82F6)
val TrackBlueMuted = Color(0x223B82F6)

// Typography & Borders
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val RailBorder = Color(0xFF334155)
val RailBorderSubtle = Color(0x22FFFFFF)
